# LIVRA App — by Arifa Malik Bristy

## Deploy to Vercel in 5 steps

1. Go to **github.com** → create a free account
2. Click **New Repository** → name it `livra-app` → Upload all these files
3. Go to **vercel.com** → sign in with GitHub
4. Click **Add New Project** → select `livra-app`
5. Click **Deploy** → your app is live! ✦

## Connect Facebook & Instagram
1. Go to developers.facebook.com
2. Create App → Business type
3. Add Instagram Graph API + Facebook Pages API
4. Copy your Access Token
5. Send it to your developer to plug in

## Your live URL will be:
https://livra-app.vercel.app

---
LIVRA © 2024 by Arifa Malik Bristy. All rights reserved.
